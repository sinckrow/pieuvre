<div id="bandeau">
</div>


 <ul class="nav nav-tabs">
  <li role="presentation"><a href="index.php"> Accueil </a></li>
  <li role="presentation"><a href="index.php?uc=administrer&action=voirCitationsAdmin"> citations </a></li>


  <li role="presentation"><a href="index.php?uc=administrer&action=ajoutCitation">Ajouter</a></li>
  <li id="deco" role="presentation"><a href="index.php?uc=administrer&action=deconnexion">Déconnexion</a></li>
</ul>
 