﻿<div class="message">
<center><ul><li>
<?php
      echo $message;
?>
</li>
</ul></center>
</div>