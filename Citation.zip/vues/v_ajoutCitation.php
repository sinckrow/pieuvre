

<center><h2> Nouvelle citation</h2></center>

<br/><br/>
<form method="post" action="index.php?uc=administrer&action=validerAjout">
	<div class="row" >
  	<div class="col-sm-3">
		<input type="text" name="auteur" class="form-control" placeholder="Auteur">
	</div>
	<div class="col-sm-3">
 		<input type="text" name="ouvrage" class="form-control" placeholder="Ouvrage" />
		</div></div><br/>

<div class="row" >
	<div class="col-sm-6">
<textarea class="form-control" type="text" name="citation" placeholder="Citation"></textarea>
</div>
</div><br/>
<center><div class="col-sm-6"><input type="submit" value="Valider">
<input type="reset" value="Annuler"></div></center>
</form>

