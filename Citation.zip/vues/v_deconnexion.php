<form method="post" action="index.php?uc=administrer&action=deconnexion"><br>
<input type="submit" value="Deconnexion">
</form>