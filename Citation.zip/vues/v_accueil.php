	<h1><center> Bienvenue sur les citations </center></h1>

	<center><a href="index.php?uc=administrer&action=connexion" >connexion</a></center>

<br/><br/>


