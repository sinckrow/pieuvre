
<form method="post" action="index.php?uc=administrer&action=validConnexion">
<br> Administration<br>
<p> User* <input type="text" name="user"/></p>
<p> mdp* <input type="password" name="mdp"/> </p>
<input type="submit" value="Valider"> <input type="reset" value="Annuler">

</form>